#!/usr/bin/env python3.7.9
# -*- coding:utf-8 -*-
# @Time   : 2021/9/7 08:41
# @Author : Kitty
# @File   : get_data_domain.py
# @SoftWare: PyCharm
# version=''
from day08_2.case.test_login import get_data

if __name__ == '__main__':
    print(get_data())
